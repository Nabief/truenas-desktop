const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(['url', 'token', 'premium', 'connections', 'dir'], (c) => {
  $('url').value = c.url || ''; $('token').value = c.token || '';
  if (c.premium) $('premium').value = c.premium;
  if (c.connections) $('connections').value = String(c.connections);
  $('dir').value = c.dir || '';
});

function setStatus(text, color) {
  const s = $('status');
  s.textContent = text;
  s.style.color = color || '#8a9bbf';
}

// Message d'auth : texte + lien cliquable qui ouvre le portail (CSP-safe, sans onclick inline)
function setStatusAuth(msg, loginUrl) {
  const s = $('status');
  s.textContent = '';
  s.style.color = '#fbbf24';
  s.appendChild(document.createTextNode('🔒 ' + msg + ' '));
  const a = document.createElement('a');
  a.textContent = 'Ouvrir la page de connexion';
  a.href = loginUrl;
  a.style.color = '#38bdf8';
  a.style.cursor = 'pointer';
  a.style.textDecoration = 'underline';
  a.addEventListener('click', (e) => {
    e.preventDefault();
    try { chrome.tabs.create({ url: loginUrl }); }
    catch (_) { window.open(loginUrl, '_blank'); }
  });
  s.appendChild(a);
  s.appendChild(document.createTextNode(', authentifiez-vous, puis relancez le test.'));
}

$('save').onclick = () => {
  chrome.storage.sync.set({
    url: $('url').value.trim(), token: $('token').value.trim(),
    premium: $('premium').value, connections: Number($('connections').value), dir: $('dir').value.trim()
  }, () => setStatus('✅ Enregistré', '#3ecf8e'));
};

$('test').onclick = async () => {
  const base = $('url').value.trim().replace(/\/+$/, '');
  const token = $('token').value.trim();
  if (!base) { setStatus('❌ Renseignez l’URL fileops', '#f87171'); return; }

  let loginOrigin = '';
  try { loginOrigin = new URL(base).origin + '/'; }
  catch (_) { setStatus('❌ URL invalide', '#f87171'); return; }

  setStatus('Test…', '#8a9bbf');

  let r;
  try {
    r = await fetch(base + '/downloads/list', { headers: { 'X-Fileops-Token': token } });
  } catch (e) {
    setStatus('❌ Impossible de joindre le NAS (URL, HTTPS ou réseau) : ' + e.message, '#f87171');
    return;
  }

  const ct = (r.headers.get('content-type') || '').toLowerCase();

  // Réponse HTML ou redirection = on est passé par le portail d'authentification (Authelia),
  // pas par l'API fileops. C'est la cause du « Unexpected token '<' ».
  if (r.redirected || !ct.includes('application/json')) {
    setStatusAuth(
      "Vous n'êtes pas connecté au portail sécurisé (Authelia) dans ce navigateur.",
      (r.redirected && r.url) ? r.url : loginOrigin
    );
    return;
  }

  if (r.status === 401 || r.status === 403) {
    setStatus('❌ Jeton d’accès refusé — vérifiez le X-Fileops-Token', '#f87171');
    return;
  }

  let j;
  try { j = await r.json(); }
  catch (_) {
    setStatusAuth("Réponse inattendue du serveur (page HTML au lieu de l'API).", loginOrigin);
    return;
  }

  if (j.ok) {
    setStatus('✅ Connexion OK — ' + (j.downloads ? j.downloads.length : 0) + ' téléchargement(s)', '#3ecf8e');
  } else {
    setStatus('❌ ' + (j.error || ('HTTP ' + r.status)), '#f87171');
  }
};
