const $ = (id) => document.getElementById(id);
chrome.storage.sync.get(['url', 'token', 'premium', 'connections', 'dir'], (c) => {
  $('url').value = c.url || ''; $('token').value = c.token || '';
  if (c.premium) $('premium').value = c.premium;
  if (c.connections) $('connections').value = String(c.connections);
  $('dir').value = c.dir || '';
});
$('save').onclick = () => {
  chrome.storage.sync.set({
    url: $('url').value.trim(), token: $('token').value.trim(),
    premium: $('premium').value, connections: Number($('connections').value), dir: $('dir').value.trim()
  }, () => { $('status').textContent = '✅ Enregistré'; $('status').style.color = '#3ecf8e'; });
};
$('test').onclick = async () => {
  const url = $('url').value.trim().replace(/\/+$/, ''), token = $('token').value.trim();
  $('status').textContent = 'Test…'; $('status').style.color = '#8a9bbf';
  try {
    const r = await fetch(url + '/downloads/list', { headers: { 'X-Fileops-Token': token } });
    const j = await r.json();
    if (j.ok) { $('status').textContent = '✅ Connexion OK — ' + (j.downloads ? j.downloads.length : 0) + ' téléchargement(s)'; $('status').style.color = '#3ecf8e'; }
    else throw new Error(j.error || r.status);
  } catch (e) { $('status').textContent = '❌ ' + e.message; $('status').style.color = '#f87171'; }
};
