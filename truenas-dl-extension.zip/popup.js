const $ = (id) => document.getElementById(id);
let CFG = {}, timer = null, BASE = '';

const STATES = {
  downloading: ['En cours', '#38bdf8', 'rgba(56,189,248,.15)'],
  queued:      ['En file',  '#8a9bbf', 'rgba(138,155,191,.15)'],
  paused:      ['En pause', '#f0b429', 'rgba(240,180,41,.15)'],
  extracting:  ['Extraction', '#a78bfa', 'rgba(167,139,250,.15)'],
  done:        ['Terminé',  '#3ecf8e', 'rgba(62,207,142,.15)'],
  error:       ['Erreur',   '#f87171', 'rgba(248,113,113,.15)'],
  canceled:    ['Annulé',   '#8a9bbf', 'rgba(138,155,191,.12)'],
};

function fmtBytes(n) {
  n = Number(n) || 0;
  if (n < 1024) return n + ' o';
  const u = ['Ko', 'Mo', 'Go', 'To']; let i = -1;
  do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
  return n.toFixed(n < 10 ? 1 : 0) + ' ' + u[i];
}
function fmtSpeed(s) { return s > 0 ? fmtBytes(s) + '/s' : ''; }
function fmtEta(s) {
  s = Number(s) || 0; if (s <= 0) return '';
  if (s < 60) return s + 's';
  if (s < 3600) return Math.floor(s / 60) + 'm' + (s % 60) + 's';
  return Math.floor(s / 3600) + 'h' + Math.floor((s % 3600) / 60) + 'm';
}

function show(which) {
  ['err', 'cfg', 'empty', 'list'].forEach((k) => $(k).classList.toggle('hide', k !== which && !(which === 'list' && k === 'list')));
  if (which !== 'list') $('list').classList.add('hide');
}

async function api(pathname, body) {
  return fetch(BASE + pathname, {
    method: body ? 'POST' : 'GET',
    headers: Object.assign({ 'X-Fileops-Token': CFG.token }, body ? { 'Content-Type': 'application/json' } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
}

async function ctl(id, action) {
  try { await api('/downloads/' + action, { id }); refresh(); } catch (e) {}
}

function render(items) {
  if (!items.length) { $('list').innerHTML = ''; $('list').classList.add('hide'); $('empty').classList.remove('hide'); return; }
  $('empty').classList.add('hide'); $('list').classList.remove('hide');
  $('list').innerHTML = items.map((it) => {
    const st = STATES[it.status] || [it.status, '#8a9bbf', 'rgba(138,155,191,.15)'];
    const tot = Number(it.total) || 0, dl = Number(it.downloaded) || 0;
    const pct = tot > 0 ? Math.min(100, Math.round(dl / tot * 100)) : (it.status === 'done' ? 100 : 0);
    const barColor = it.status === 'error' ? '#f87171' : (it.status === 'done' ? '#3ecf8e' : (it.status === 'paused' ? '#f0b429' : '#38bdf8'));
    const sizeTxt = tot > 0 ? fmtBytes(dl) + ' / ' + fmtBytes(tot) : (dl > 0 ? fmtBytes(dl) : '');
    const sp = it.status === 'downloading' ? fmtSpeed(it.speed) : '';
    const eta = it.status === 'downloading' ? fmtEta(it.eta) : '';
    const right = [sp, eta ? '⏳ ' + eta : ''].filter(Boolean).join(' · ');
    let acts = '';
    if (it.status === 'downloading' || it.status === 'queued') acts += `<button data-a="pause" data-id="${it.id}">⏸ Pause</button>`;
    if (it.status === 'paused') acts += `<button data-a="resume" data-id="${it.id}">▶ Reprendre</button>`;
    if (it.status === 'downloading' || it.status === 'queued' || it.status === 'paused') acts += `<button data-a="cancel" data-id="${it.id}">✕</button>`;
    if (it.status === 'done' || it.status === 'error' || it.status === 'canceled') acts += `<button data-a="remove" data-id="${it.id}">🗑</button>`;
    const via = it.via && it.via !== 'direct' ? '⚡ ' + it.via : (it.connections > 1 ? '⇅' + it.connections : '');
    return `<div class="it">
      <div class="top"><span class="nm">${(it.filename || 'download').replace(/</g, '&lt;')}</span>
        <span class="bdg" style="color:${st[1]};background:${st[2]}">${st[0]}${pct && it.status === 'downloading' ? ' ' + pct + '%' : ''}</span></div>
      <div class="bar"><i style="width:${pct}%;background:${barColor}"></i></div>
      <div class="meta"><span class="sp">${sizeTxt}</span><span>${right}</span></div>
      ${it.error ? `<div class="meta" style="color:#f87171;margin-top:3px">${String(it.error).replace(/</g, '&lt;').slice(0, 80)}</div>` : ''}
      <div class="act">${acts}<span class="via">${via}</span></div>
    </div>`;
  }).join('');
  $('list').querySelectorAll('button[data-a]').forEach((b) => {
    b.onclick = () => ctl(b.getAttribute('data-id'), b.getAttribute('data-a'));
  });
}

async function refresh() {
  if (!CFG.url || !CFG.token) { $('cfg').classList.remove('hide'); return; }
  try {
    const r = await api('/downloads/list');
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || r.status);
    $('err').classList.add('hide'); $('cfg').classList.add('hide');
    render(j.downloads || []);
  } catch (e) {
    $('err').textContent = '⚠ Connexion impossible au NAS.\n' + e.message;
    $('err').classList.remove('hide'); $('list').classList.add('hide'); $('empty').classList.add('hide');
  }
}

function startPoll() { refresh(); if (timer) clearInterval(timer); timer = setInterval(refresh, 1500); }

chrome.storage.sync.get(['url', 'token'], (c) => {
  CFG = c; BASE = (c.url || '').replace(/\/+$/, '');
  $('opts').onclick = () => chrome.runtime.openOptionsPage();
  $('cfgbtn') && ($('cfgbtn').onclick = () => chrome.runtime.openOptionsPage());
  $('refresh').onclick = refresh;
  $('open').onclick = () => { if (BASE) chrome.tabs.create({ url: BASE.replace(/\/fileops$/, '') }); };
  $('clear').onclick = async () => { try { await fetch(BASE + '/downloads/clear', { method: 'POST', headers: { 'X-Fileops-Token': CFG.token } }); refresh(); } catch (e) {} };
  if (!c.url || !c.token) { $('cfg').classList.remove('hide'); return; }
  startPoll();
});
window.addEventListener('unload', () => { if (timer) clearInterval(timer); });
