const M_LINK = 'tnasdl-link', M_PAGE = 'tnasdl-page';
function ensureMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: M_LINK, title: 'Envoyer ce lien au NAS', contexts: ['link'] });
    chrome.contextMenus.create({ id: M_PAGE, title: 'Choisir les liens de la page à envoyer…', contexts: ['page', 'selection'] });
  });
}
chrome.runtime.onInstalled.addListener(ensureMenus);
if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(ensureMenus);

async function getCfg() { return await chrome.storage.sync.get(['url', 'token', 'premium', 'connections', 'dir']); }

/* Badge sur l'icône : nombre de téléchargements actifs, rafraîchi par alarme. */
async function updateBadge() {
  const c = await getCfg();
  if (!c.url || !c.token) { chrome.action.setBadgeText({ text: '' }); return; }
  try {
    const r = await fetch(c.url.replace(/\/+$/, '') + '/downloads/list', { headers: { 'X-Fileops-Token': c.token } });
    const j = await r.json();
    const active = (j.downloads || []).filter((d) => d.status === 'downloading' || d.status === 'queued' || d.status === 'extracting').length;
    chrome.action.setBadgeBackgroundColor({ color: '#0a84ff' });
    chrome.action.setBadgeText({ text: active ? String(active) : '' });
  } catch (e) { chrome.action.setBadgeText({ text: '' }); }
}
chrome.alarms.create('tnasdl-badge', { periodInMinutes: 1 });
if (chrome.alarms.onAlarm) chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'tnasdl-badge') updateBadge(); });
if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(updateBadge);
chrome.runtime.onInstalled.addListener(updateBadge);
function notify(msg) { try { chrome.notifications.create({ type: 'basic', iconUrl: 'icon.png', title: 'TrueNAS Download', message: String(msg) }); } catch (e) {} }

async function sendUrls(urls) {
  const c = await getCfg();
  if (!c.url || !c.token) { notify('Configure l’extension (URL + jeton) dans les options.'); chrome.runtime.openOptionsPage(); return; }
  const base = c.url.replace(/\/+$/, '');
  const payload = { urls: urls, premium: c.premium || 'auto' };
  if (c.connections) payload.connections = Number(c.connections);
  if (c.dir) payload.dir = c.dir;
  try {
    const r = await fetch(base + '/downloads/add-batch', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Fileops-Token': c.token }, body: JSON.stringify(payload) });
    const ct = (r.headers.get('content-type') || '').toLowerCase();
    // HTML / redirection = portail d'authentification (Authelia), pas l'API : on ouvre la connexion.
    if (r.redirected || !ct.includes('application/json')) {
      let origin = base;
      try { origin = new URL(base).origin + '/'; } catch (_) {}
      notify('🔒 Non connecté au portail sécurisé (Authelia). J’ouvre la page de connexion — authentifiez-vous puis réessayez.');
      try { chrome.tabs.create({ url: (r.redirected && r.url) ? r.url : origin }); } catch (_) {}
      return;
    }
    if (r.status === 401 || r.status === 403) { notify('❌ Jeton d’accès refusé — vérifiez le jeton dans les options.'); return; }
    const j = await r.json();
    if (!r.ok || j.error) { notify('Erreur : ' + (j.error || r.status)); return; }
    notify('✅ ' + (j.added || 0) + ' ajouté(s)' + (j.failed ? (' · ' + j.failed + ' échec(s)') : ''));
  } catch (e) { notify('Erreur : ' + e.message); }
}

/* Sélecteur injecté dans la page : liste les liens, l'utilisateur coche, puis envoie. */
function pagePicker(cfg) {
  var base = (cfg.url || '').replace(/\/+$/, ''), token = cfg.token;
  var H = ['1fichier.com','rapidgator.net','uptobox.com','turbobit.net','nitroflare.com','ddownload.com','mega.nz','mediafire.com','fikper.com','uploaded.net','katfile.com','gofile.io','pixeldrain.com','krakenfiles.com','send.cm','1cloudfile.com','dailyuploads.net','usersdrive.com','file.al','frdl.to','hitfile.net','filespace.com','clicknupload.org','wupfile.com','hexload.com','elitefile.net'];
  var E = /\.(zip|rar|7z|iso|mkv|mp4|avi|pdf|tar|gz|exe|dmg|apk|epub|flac|mp3|mov|wmv|m4v|bin|img)(\?|$)/i;
  var RE = /https?:\/\/[^\s"'<>\)\]\}]+/g;
  function host(h){ try { return new URL(h).hostname.replace(/^www\./,''); } catch(e){ return ''; } }
  function isMatch(h){ var ho=host(h); return H.some(function(d){ return ho===d || ho.endsWith('.'+d); }) || E.test(h); }
  var pre={}, order=[];
  function add(h,p){ if(!h) return; h=String(h).trim().replace(/[.,;:!]+$/,''); if(!/^https?:/.test(h)||pre.hasOwnProperty(h)) return; pre[h]=p; order.push(h); }
  var sel=(window.getSelection?window.getSelection().toString():'')||'';
  (sel.match(RE)||[]).forEach(function(h){ add(h,true); });
  var a=document.getElementsByTagName('a'); for(var i=0;i<a.length;i++){ add(a[i].href, isMatch(a[i].href)); }
  var da=document.querySelectorAll('[data-href],[data-url],[data-link],[data-clipboard-text]');
  for(var i=0;i<da.length;i++){ var el=da[i]; ['data-href','data-url','data-link','data-clipboard-text'].forEach(function(at){ var v=el.getAttribute(at); if(v) add(v, isMatch(v)); }); }
  var ck=document.querySelectorAll('[onclick]'); for(var i=0;i<ck.length;i++){ var oc=ck[i].getAttribute('onclick')||''; var mm=oc.match(RE); if(mm) for(var k=0;k<mm.length;k++) add(mm[k], isMatch(mm[k])); }
  var txt=(document.body?document.body.innerText:'')||''; var tm=txt.match(RE)||[]; for(var i=0;i<tm.length;i++) add(tm[i], isMatch(tm[i]));
  if(!order.length){ alert('Aucun lien trouvé sur cette page.'); return; }
  var ex=document.getElementById('__tnasdl'); if(ex) ex.remove();
  var ov=document.createElement('div'); ov.id='__tnasdl';
  ov.style.cssText='position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;font-family:system-ui,-apple-system,sans-serif;';
  var box=document.createElement('div');
  box.style.cssText='background:#0f1a2e;color:#e8edf5;width:min(720px,94vw);max-height:82vh;display:flex;flex-direction:column;border-radius:12px;border:1px solid rgba(255,255,255,.15);box-shadow:0 20px 60px rgba(0,0,0,.5);overflow:hidden;';
  var rows='';
  order.forEach(function(h){
    rows+='<label style="display:flex;gap:8px;align-items:flex-start;padding:6px 4px;border-bottom:1px solid rgba(255,255,255,.06);font-size:12px;cursor:pointer;"><input type="checkbox" class="__tnc" data-u="'+encodeURIComponent(h)+'" '+(pre[h]?'checked':'')+' style="margin-top:2px;"><span style="word-break:break-all;'+(pre[h]?'':'opacity:.55;')+'">'+h.replace(/</g,'&lt;')+'</span></label>';
  });
  box.innerHTML='<div style="padding:12px 16px;border-bottom:1px solid rgba(255,255,255,.1);display:flex;align-items:center;gap:12px;"><b style="flex:1;">Envoyer au NAS</b><label style="font-size:12px;cursor:pointer;display:flex;gap:6px;align-items:center;"><input type="checkbox" id="__tnall"> tout</label><span id="__tncnt" style="font-size:12px;color:#8a9bbf;min-width:60px;text-align:right;"></span></div>'
    +'<div style="overflow:auto;padding:6px 12px;flex:1;">'+rows+'</div>'
    +'<div style="padding:12px 16px;border-top:1px solid rgba(255,255,255,.1);display:flex;gap:8px;justify-content:flex-end;"><button id="__tncancel" style="padding:8px 14px;border-radius:8px;border:1px solid rgba(255,255,255,.2);background:transparent;color:#e8edf5;cursor:pointer;">Annuler</button><button id="__tnsend" style="padding:8px 16px;border-radius:8px;border:1px solid rgba(62,207,142,.4);background:rgba(62,207,142,.2);color:#3ecf8e;cursor:pointer;">Envoyer</button></div>';
  ov.appendChild(box); document.body.appendChild(ov);
  function cbs(){ return box.querySelectorAll('.__tnc'); }
  function upd(){ var n=0,t=0; cbs().forEach(function(c){ t++; if(c.checked) n++; }); box.querySelector('#__tncnt').textContent=n+' / '+t; }
  box.querySelector('#__tnall').onchange=function(e){ cbs().forEach(function(c){ c.checked=e.target.checked; }); upd(); };
  box.addEventListener('change', upd); upd();
  function close(){ ov.remove(); }
  box.querySelector('#__tncancel').onclick=close;
  ov.addEventListener('click', function(e){ if(e.target===ov) close(); });
  box.querySelector('#__tnsend').onclick=function(){
    var urls=[]; cbs().forEach(function(c){ if(c.checked) urls.push(decodeURIComponent(c.getAttribute('data-u'))); });
    if(!urls.length){ close(); return; }
    var b=box.querySelector('#__tnsend'); b.textContent='Envoi…'; b.disabled=true;
    var payload={ urls: urls, premium: cfg.premium || 'auto' };
    if (cfg.connections) payload.connections = Number(cfg.connections);
    if (cfg.dir) payload.dir = cfg.dir;
    fetch(base+'/downloads/add-batch',{method:'POST',headers:{'Content-Type':'application/json','X-Fileops-Token':token},body:JSON.stringify(payload)}).then(function(r){ return r.json(); }).then(function(j){ alert('OK : '+(j.added||0)+' ajouté(s)'+(j.failed?(' - '+j.failed+' échec(s)'):'')); close(); }).catch(function(e){ alert('Erreur : '+e); b.textContent='Envoyer'; b.disabled=false; });
  };
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === M_LINK && info.linkUrl) { sendUrls([info.linkUrl]); return; }
  if (info.menuItemId === M_PAGE) {
    const c = await getCfg();
    if (!c.url || !c.token) { notify('Configure l’extension (URL + jeton) dans les options.'); chrome.runtime.openOptionsPage(); return; }
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: pagePicker, args: [c] }); }
    catch (e) { notify('Erreur : ' + e.message); }
  }
});
